open Execute.bat
open http://localhost:8000/