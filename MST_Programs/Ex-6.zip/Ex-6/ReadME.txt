6a) open "Ex-06 Binding.html"

6b) open "Ex-06 Events"

6c) 

[Requirements : Mysql server (Xampp)]
[if xampp is  not there in computer, this code will not work]


open Xampp
start mysql
start apache
put the "Ex-06-MySQL" folder in "xampp/htdocs" folder
open http://localhost/Ex-06-MySQL/index.php
open http://localhost/Ex-06-MySQL/insert.php
open http://localhost/Ex-06-MySQL/select.php
