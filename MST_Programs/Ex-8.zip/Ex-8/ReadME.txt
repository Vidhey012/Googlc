open "Ex-08 B_Building.html"

open "Ex-08 I_Validation.html"
