function add (a, b){
    console.log(`${a} + ${b} = ${a+b}`)
}


function sub (a, b){
    console.log(`${a} - ${b} = ${a-b}`)
}


function mul (a, b){
    console.log(`${a} * ${b} = ${a*b}`)
}


module.exports = {add, sub, mul}
