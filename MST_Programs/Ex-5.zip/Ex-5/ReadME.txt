[Requirements : Mysql server (Xampp)]
[if xampp is  not there in computer, this code will not work]


open Xampp
start mysql
open http://localhost/phpmyadmin/
create db "mydb"
open Execute.bat

In the end of "Ex-05 EmpDB.js" code, comment the previous line and uncomment next line and open Execute.bat
Repeat this step until last line

